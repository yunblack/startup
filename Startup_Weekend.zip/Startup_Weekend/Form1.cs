﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Startup_Weekend
{
    public partial class Main : MetroFramework.Forms.MetroForm
    {
        public Main()
        {
            InitializeComponent();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void signup_btn_Click(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            info.BringToFront();
            main_panel.Visible = false;
        }

        private void next02_Click(object sender, EventArgs e)
        {
            main_main.BringToFront();
            info.Visible = false;
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            btn1_panel.BringToFront();
            main_main.Visible = false;
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            btn2_panel.BringToFront();
            main_main.Visible = false;
        }



        private void label4_Click(object sender, EventArgs e)
        {
            btn1_Click(sender, e);
        }

        private void label5_Click(object sender, EventArgs e)
        {
            btn2_Click(sender, e);
        }

        private void btn1_panel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btn1_return_Paint(object sender, PaintEventArgs e)
        {
            main_main.BringToFront();
            main_main.Visible=true;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            main_main.BringToFront();
            main_main.Visible = true;
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            main_main.BringToFront();
            main_main.Visible = true;
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
